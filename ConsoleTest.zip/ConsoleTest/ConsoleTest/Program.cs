﻿using System;
using System.Linq;
using System.Text;

namespace ConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.Write("Enter a alphabet :");

                string strInput = Console.ReadLine();
                //validate input data and return error msg
                string valInput = validateInput(strInput);
                if(valInput == string.Empty)
                {
                    char inputChr = char.Parse(strInput);
                    PrintDiamond(char.ToUpper(inputChr));
                    Console.ReadLine();
                }
                else
                {
                    Console.Write(valInput);
                    Console.WriteLine();
                   
                }
               
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
                Console.WriteLine();     
            }

            Main(null);
        }
            

        private const string SPACE = " ";

        public static void PrintDiamond(char inputChar) // C
        {
            //alphabet declaration
            char[] alphaChr = { 'A', 'B', 'C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
            int inputIndex = 0;

            //find out the index of the letter 
            inputIndex = Array.IndexOf(alphaChr, inputChar) + 1;   //3

            //square size to build up the array
            int squareSize = (inputIndex * 2) - 1;  //5

            //total lines to output
            string[] lines = new string[squareSize];


            for (int i = 0; i < inputIndex; i++)
            {
                //declare string builder for better working with strings manipulation
                StringBuilder sbInner = new StringBuilder();

                //initial spacing till BEFORE the middle point, i.e. inputIndex - 1
                for (int j = 1; j < inputIndex - i; j++)
                    sbInner.Append(SPACE);

                //after all the spacing... write the letter
                sbInner.Append(alphaChr[i]);

                //after the letter... found out how many empty space needs to be filled
                int AdditionalSpaceToBeAdded = inputIndex - sbInner.ToString().Length;
                for (int j = 1; j <= AdditionalSpaceToBeAdded; j++)
                    sbInner.Append(SPACE);

                //after the space has been filled, just reverse the string with slicing of first char
                string lineReversed = string.Join("", sbInner.ToString().Reverse());
                lines[i] = sbInner.ToString() + lineReversed.Substring(1);
            }

            //just append the lines in desc order as we already have that data
            for (int i = inputIndex; i < squareSize; i++)
                lines[i] = lines[squareSize - (i + 1)];

            foreach (var item in lines)
                Console.WriteLine(item);

           // Console.ReadKey();
        }

        public static string validateInput(string inputStr)
        {
            string retStr = string.Empty; ;
            bool result = string.IsNullOrEmpty(inputStr);
            if (!result)
            {
                result = inputStr.All(Char.IsLetter);
                if(result)
                {
                    if(inputStr.Length > 1)
                    {
                        retStr = "Please enter a single alphabet.";
                    }
                }
                else
                {
                    retStr = "Please enter the alphabet(numerics, special characters not allowed).";
                }  
            }
            else
            {
                retStr = "Please enter a alphabet.";    
            }

            return retStr;
        }

    }



}
